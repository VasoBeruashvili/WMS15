﻿


Ext.Ajax.disableCaching = false;


Ext.override(Ext.MessageBox, {
    buttonText: { yes: "დიახ", no: "არა", cancel: "გაუქმება", ok: "დასტური" }
});

//TODO default root

Ext.override(Ext.data.HasOneAssociation, {
    createSetter: function () {
        var me = this,
        foreignKey = me.foreignKey,
        instanceName = me.instanceName;

        //'this' refers to the Model instance inside this function
        return function (value, options, scope) {
            var setByRecord = value && value.isModel,
            valueToSet = setByRecord ? value.getId() : value;

            if (setByRecord) {
                this[instanceName] = value;
            }
            else if (this[instanceName] instanceof Ext.data.Model && this.get(foreignKey) !== valueToSet) {
                /*
                * It means we are updating only the value of the field, 
                * thus we have to delete the previous associated record instance reference.
                */
                delete this[instanceName];
            }

            this.set(foreignKey, valueToSet);

            if (Ext.isFunction(options)) {
                options = {
                    callback: options,
                    scope: scope || this
                };
            }

            if (Ext.isObject(options)) {
                return this.save(options);
            }
        };
    }
});


Ext.define('ModelExtension', {
    override: 'Ext.data.Model',
    //for self referencing models
    serializeToJson: function (seenKeys, depth) {
        var me = this,
            associations = me.associations.items,
            associationCount = associations.length,
            associationData = {},
            // We keep 3 lists at the same index instead of using an array of objects.
            // The reasoning behind this is that this method gets called a lot
            // So we want to minimize the amount of objects we create for GC.
            toRead = [],
            toReadKey = [],
            toReadIndex = [],
            associatedStore, associatedRecords, associatedRecord, o, index, result, seenDepth,
            associationId, associatedRecordCount, association, i, j, type, name;
        for (i = 0; i < associationCount; i++) {
            association = associations[i];
            associationId = association.associationId;
            seenDepth = seenKeys[associationId];
            if (seenDepth && seenDepth !== depth) {
                //continue;
            }
            seenKeys[associationId] = depth;
            type = association.type;
            name = association.name;
            if (type == 'hasMany') {
                //this is the hasMany store filled with the associated data
                associatedStore = me[association.storeName];
                //we will use this to contain each associated record's data
                associationData[name] = [];
                //if it's loaded, put it into the association data
                if (associatedStore && associatedStore.getCount() > 0) {
                    associatedRecords = associatedStore.data.items;
                    associatedRecordCount = associatedRecords.length;
                    //now we're finally iterating over the records in the association. Get
                    // all the records so we can process them
                    for (j = 0; j < associatedRecordCount; j++) {
                        associatedRecord = associatedRecords[j];
                        associationData[name][j] = associatedRecord.getData();
                        toRead.push(associatedRecord);
                        toReadKey.push(name);
                        toReadIndex.push(j);
                    }
                }
            } else if (type == 'belongsTo' || type == 'hasOne') {
                associatedRecord = me[association.instanceName];
                // If we have a record, put it onto our list
                if (associatedRecord !== undefined) {
                    associationData[name] = associatedRecord.getData();
                    toRead.push(associatedRecord);
                    toReadKey.push(name);
                    toReadIndex.push(-1);
                }
            }
        }
        for (i = 0, associatedRecordCount = toRead.length; i < associatedRecordCount; ++i) {
            associatedRecord = toRead[i];
            o = associationData[toReadKey[i]];
            index = toReadIndex[i];
            result = associatedRecord.serializeToJson(seenKeys, depth + 1);
            if (index === -1) {
                Ext.apply(o, result);
            } else {
                Ext.apply(o[index], result);
            }
        }
        return associationData;
    }


});



Ext.define('StoreExtension', {
    override: 'Ext.data.Store',


    getRecords: function () {
        var items = [];
        var st = this;

        st.each(function (item, index) {
            items.push(item);

            return true;
        });

        return items;
    },

    getNotDeletedRecords: function () {

        var items = [];
        var st = this;

        st.each(function (item, index) {
            if (!item.get('Deleted')) {
                items.push(item);
            }

            return true;
        });

        return items;
    },


    containsKey: function (key, value) {
        var store = this;

        return store.findExact(key, value) != -1;

    },

    stoplLoad: function () {
        Ext.Ajax.abort(this.proxy.activeRequest);
    },

    addExtraParams: function (extraParams) {
        if (extraParams === null || extraParams === undefined) return null;
        if (this.proxy.extraParams !== null) {
            var tmpParams = Ext.apply(this.proxy.extraParams, extraParams);//changed applyIf to apply
            this.proxy.extraParams = tmpParams;
        }
        else {
            this.proxy.extraParams = extraParams;
        }
    },

    clearExtraParams: function () {
        this.proxy.extraParams = null;
    }
});




Ext.define('GridExtension', {
    override: 'Ext.grid.Panel',

    initComponent: function () {
        if (this.storeClassName != null) {
            this.store = Ext.create(this.storeClassName, {

            });
        }

        this.columnLines = true;

        this.callParent(arguments);

        if (this.down('pagingtoolbar') != null) {
            this.down('pagingtoolbar').store = this.store;
        }




    },

    loadRecords: function (modelArray) {
        if (this.store != null) {
            var store = this.store;
            store.loadRecords(modelArray);
        }

    },

    cleanUp: function () {
        if (this.store != null) {
            this.store.removeAll();
        }
    },


    selectRecord: function (model) {
        var grid = this;
        if (model != null) {
            grid.getSelectionModel().select(model);
        }

    },

    //deleteModel: function (model) {
    //    if (this.store != null) {
    //        var store = this.store;
    //        SetDelete(model);
    //        store.remove(model);
    //    }
    //},

    //TODO gasakaetebelia
    getRecordIndex: function (model) {
        var store = this.store;

        return store.indexOf(model);

    },

    recordSelected: function () {
        var selection = this.getSelectionModel().getSelection();

        return selection.length > 0;
    },

    getSelectedRecord: function () {
        if (this.recordSelected()) {
            return this.getSelectionModel().getSelection()[0];
        }
    },
    getSelectedRecords: function () {
        if (this.recordSelected()) {
            return this.getSelectionModel().getSelection();
        }
    }



});


var FNKEY = ['ctrl', 'alt', 'shift'];

//binding: {
//    ctrl: true,
//    btnItemId: '#myButton',
//    fn: function(){},
//    key: 'S'
//}


Ext.define('WindowExtension', {
    override: 'Ext.window.Window',
    resizable: false,

    initComponent: function () {
        //this.callParent(arguments);
        var me = this;


        me.listeners = {
            show: function () {
                if (me.keyMapConfig != null) {

                    var map = new Ext.util.KeyMap({
                        target: me.getEl(),
                        //ignoreInputFields: true
                    });

                    var defaultBinding = { /*ctrl: true*,*/ defaultEventAction: 'stopEvent' };

                    Ext.each(me.keyMapConfig.bindings, function (binding) {
                        //map.addBinding({
                        //    ctrl: true,
                        //    //shift: true,
                        //    key: 83,
                        //    fn: function () { console.log('llll'); return false; },
                        //    defaultEventAction: 'stopEvent'//stopEvent'
                        //});

                        //return false;

                        Ext.applyIf(binding, defaultBinding);
                        if (binding.btnItemId != null) {
                            binding.fn = function () {
                                var btn = me.down('#' + binding.btnItemId);
                                console.log('lllll');

                                if (!btn.isDisabled()) {

                                    if (btn.handler != null) {
                                        btn.handler(button);
                                    }
                                    else {
                                        btn.fireEvent('click', btn);
                                    }
                                }

                                return false;
                            }
                        }
                        map.addBinding(binding);

                        return true;
                    });
                }
            }
        };


        this.callParent(arguments);




    }
});







Ext.define('SIS.view.override.OrgUnitsCombo', {
    override: 'SIS.view.OrgUnitsCombo',
    editable: false,
    displayField: 'Name',
    store: 'OrganizationalUnitsStore',
    valueField: 'ID',
    initComponent: function () {
        this.ParentID = OrganizationalUnitsDictionary[this.ParentCode];
        var me = this;
        me.callParent(arguments);
    }
});

Ext.define('ComboExtension', {
    override: 'Ext.form.field.ComboBox',

    forceSelection: true,

    initComponent: function () {



        if (this.storeClassName != null) {
            this.store = Ext.create(this.storeClassName, {

            });
        }

        if (this.dictionaryID != null && this.store != null && this.store.proxy != null) {
            this.store.addExtraParams({ dictionaryID: this.dictionaryID });
        }

        if (this.ParentID != null && this.store != null && this.store.proxy != null) {
            this.store.addExtraParams({ ParentID: this.ParentID });
        }



        if (this.tpl != null) {
            this.tpl = new Ext.XTemplate(this.tpl);
        }

        if (this.displayTpl != null) {
            this.displayTpl = new Ext.XTemplate(this.displayTpl);
        }

        if (this.onlyActive != null) {
            this.store.addExtraParams({ OnlyActive: this.onlyActive });
        }

        this.callParent(arguments);




    },
    //shemocmeba tu araferi araris shemocmebuli
    valueNotEmpty: function () {
        if (this.getValue() !== undefined && this.getValue() !== null && this.getValue().length != 0)
            return true;
        else
            return false;
    },
    //combos recordis ageba - Jaginoff

    getSelectedRecord: function () {
        if (this.store !== null && this.store !== undefined) {
            if (this.valueNotEmpty()) {
                var ValueFieldValue = this.getValue();
                var RecordIndex = this.getStore().find(this.valueField, ValueFieldValue);
                if (RecordIndex !== null && RecordIndex !== undefined && RecordIndex != -1) {
                    return this.getStore().getAt(RecordIndex);
                }
                else {
                    return null;
                }
            }
        }
    },

    getSelectedRecords: function () {
        if (this.valueNotEmpty()) {

            var values = this.getValue();
            var recmas = new Array();
            for (var i = 0; i < values.length; i++) {
                var ValueFieldValue = values[i];
                var RecordIndex = this.getStore().find(this.valueField, ValueFieldValue);
                if (RecordIndex !== null && RecordIndex !== undefined && RecordIndex != -1) {
                    recmas.push(this.getStore().getAt(RecordIndex));
                }
            }
            return recmas;
            //Ext.each(values, function (item) {

            //},this,false);
        }
    },

    //setValueSafe: function (value) {
    //    var combo = this;
    //    if (this.store != null) {
    //        this.store.load({
    //            callback: function () {
    //                combo.setValue(value);
    //            }
    //        });
    //    }
    //}

    //addExtraParams: function (extraParams) {
    //    if (extraParams === null || extraParams === undefined) return null;
    //    if (this.store !== null) {
    //        if (this.store.proxy.extraParams !== null) {
    //            var tmpParams = Ext.applyIf(this.store.proxy.extraParams, extraParams);
    //            this.store.proxy.extraParams = tmpParams;
    //        }
    //        else {
    //            this.store.proxy.extraParams = extraParams;
    //        }
    //    }
    //},

    //clearExtraParams: function () {
    //    if (this.store !== null) {
    //        this.store.proxy.extraParams = null;
    //    }
    //},

    setValueSafe: function (value, filter) {
        var combo = this;
        var onlyActive = filter || false;

        if (this.store != null) {
            this.store.addExtraParams({ OnlyActive: onlyActive });
            this.store.load({
                callback: function () {
                    if (onlyActive && value > 0) {
                        if (this.containsKey('ID', value)) {
                            combo.setValue(value);
                        }
                        else {
                            combo.markInvalid('მნიშვნელობა აღარ არის აქტიური, აირჩეთ სხვა მნიშვნელობა!');
                            throw new Error('No such model with status Active!');
                        }
                    }
                    else {
                        combo.setValue(value);
                    }
                }
            });
        }
    },


    addExtraParams: function (extraParams) {
        this.store.addExtraParams(extraParams);
    }


});



Ext.define('NumberFieldExtension', {
    override: 'Ext.form.field.Number',
    initComponent: function () {
        this.minText = 'მინიმალური დასაშვები მნიშვნელობა არის {0}';
        this.maxText = 'მაქსიმალური დასაშვები მნიშვნელობა არის {0}';
        //this.blankText = 'ველის შევსება აუცილებელია';
        this.regexText = 'არაკორექტული მნიშვნელობა';
        this.callParent(arguments);
    }
});


Ext.define('TextFieldExtension', {
    override: 'Ext.form.field.Text',
    initComponent: function () {
        this.blankText = 'ველის შევსება აუცილებელია &nbsp';
        this.regexText = 'არაკორექტული მნიშვნელობა';
        this.minLengthText = 'სიმბოლოების მინიმალური რაოდნეობა უნდა იყოს {0}';
        this.enforceMaxLength = true;
        this.callParent(arguments);
    }
});







Ext.define('Ext.ux.data.proxy.JsonAjaxProxy', {
    extend: 'Ext.data.proxy.Ajax',
    alias: 'proxy.jsonajax',

    actionMethods: {
        create: "POST",
        read: "POST",
        update: "POST",
        destroy: "POST"
    },

    buildRequest: function (operation) {
        var request = this.callParent(arguments);

        // For documentation on jsonData see Ext.Ajax.request
        request.jsonData = request.params;
        request.params = {};

        return request;
    },

    /*
	 * @override
	 * Inherit docs. We don't apply any encoding here because
	 * all of the direct requests go out as jsonData
	 */
    applyEncoding: function (value) {
        return value;
    }

});


