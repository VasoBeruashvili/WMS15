﻿
var Resources = {

    Messages: {

        'ApproveDeleteProgram': 'sssssfsfs',

        'Questionsdeletetypeofprogram': 'გინდათ სწავლების საფეხურის წაშლა?', //პროგრამის ტიპის წაშლის დროს შეკითხვა
        'Messagetypeofprogramdeleted': 'მონაცემები წაშლილია!', //პროგრამის ტიპის წაშლის შემდეგ გამოდის შეტყობინება
        'TryingMessagetypeofprogramdelete': 'ჩანაწერი არ არის არჩეული!', //პროგრამის პიტის წაშლის დროს თუ წასაშლელი ჩანაწერი არ არის მონიშნული  გამოდის შეტყობინება
        'TryingMessagetypeofprogramdedit': 'ჩანაწერი არ არის არჩეული!', //პროგრამის პიტის რედაქტირების დროს თუ დასარედატირებელი ჩანაწერი არ არის მონიშნული  გამოდის შეტყობინება
        'Messagetypeofprogramsave': 'მონაცემები არასრულია', //პროგრამის პიტის შენახვის დროს, თუ დასახელება ველი ცარიელია გამოდის შეტყობინება

        'QuestionsdeleteStudyComponent': 'გინდათ მეცადინეობის ფორმის წაშლა??', //მეცადინეობის ფორმის წაშლის დროს შეკითხვა
        'MessageStudyComponentdeleted': 'მონაცემები წაშლილია!', // მეცადინეობის ფორმის წაშლის შემდეგ გამოდის შეტყობინება
        'TryingMessageStudyComponentdelete': 'ჩანაწერი არ არის არჩეული!', // მეცადინეობის ფორმის  წაშლის დროს თუ წასაშლელი ჩანაწერი არ არის მონიშნული  გამოდის შეტყობინება
        'TryingMessageStudyComponentedit': 'ჩანაწერი არ არის არჩეული!', // მეცადინეობის ფორმის  რედაქტირების დროს თუ დასარედატირებელი ჩანაწერი არ არის მონიშნული  გამოდის შეტყობინება
        'MessageStudyComponentsave': 'მონაცემები არასრულია', // მეცადინეობის ფორმის  შენახვის დროს: 1.თუ დასახელება ველი ცარიელია გამოდის შეტყობინება,
                                                                                                      //2.თუ დასახელება ველი შევსებულია მაგრამ HoursPerStudent,HoursPerGroup,HoursPerSubGroup-ველებიდან ერთი მაინც არ არის შევსებული გამოდის შეტყობინება

        
        'QuestionsdeleteStudyLanguage': 'გინდათ სწავლების ენის წაშლა?', //სწავლების ენის  წაშლის დროს შეკითხვა
        'MessageStudyLanguagedeleted': 'მონაცემები წაშლილია!', // სწავლების ენის  წაშლის შემდეგ გამოდის შეტყობინება
        'TryingMessageStudyLanguagedelete': 'ჩანაწერი არ არის არჩეული!', // სწავლების ენის  წაშლის დროს თუ წასაშლელი ჩანაწერი არ არის მონიშნული  გამოდის შეტყობინება
        'TryingMessageStudyLanguageedit': 'ჩანაწერი არ არის არჩეული!', // სწავლების ენის  რედაქტირების დროს თუ დასარედატირებელი ჩანაწერი არ არის მონიშნული  გამოდის შეტყობინება
        'MessageStudyLanguagesave': 'მონაცემები არასრულია!', // სწავლების ენის  შენახვის დროს, თუ დასახელება ველი ცარიელია გამოდის შეტყობინება,

        'MessageProgramTemplateAtLeastOneSemesterIsRequired': 'ბლოკის დამატებისთვის დამატებული უნდა იყოს ერთი სემესტრი მაინც!',
        'MessageProgramTemplateNoFreeSemesterLeft': 'არ დარჩა არც ერთი თავისუფალი სემესტრი!',
        'TryingProgramTemplateRemoveSemesterSelectRecord': 'მონიშნეთ ჩანაწერი!',
        'QuestionProgramTemplateRemoveSemester': 'გინდათ სემესტრის წაშლა?',
        'MessageProgramTemplate': '',
        'MessageProgramTemplate': '',
        'MessageProgramTemplate': '',
        'MessageProgramTemplate': '',
        'MessageProgramTemplate': '',
        'MessageProgramTemplate': '',
        'MessageProgramTemplate': '',
        'MessageProgramTemplate': '',
        'MessageProgramTemplate': ''
    }


};
