Ext.define('SIS.controller.Main', {
    extend: 'Ext.app.Controller'
});
